/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analisis;

import com.opencsv.bean.CsvBindByName;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * @author SEED
 */
public class tomat {

    public tomat() {
    }

public Object getMeta(String key)
    {
        Map<String,Object> datasetMeta = new LinkedHashMap<>();
        datasetMeta.put("jenisTomat", jenisTomat);
        datasetMeta.put("diameter", diameter);
        datasetMeta.put("bentuk", bentuk);        
        datasetMeta.put("usia", usia);        
        datasetMeta.put("warna", warna);        
        datasetMeta.put("hiperglikemia", hiperglikemia);        
        return datasetMeta.get(key);    
    }    
    public String getRelevancy()
    {
        if  (( hiperglikemia.equals("PRO")) && (klasifikasi.equals("PRO") )) {
            return "TP";
        }
        if  (( hiperglikemia.equals("KONTRA")) && (klasifikasi.equals("PRO") )) {
            return "FN";
        }
        if  (( hiperglikemia.equals("PRO")) && (klasifikasi.equals("KONTRA") )) {
            return "FP";
        }
        if  (( hiperglikemia.equals("KONTRA")) && (klasifikasi.equals("KONTRA") )) {
            return "TN";
        }

//        if  ( ( getLeftsDouble() == 0d) && (getKelas() == 1d) ) {
//            return "FN";
//        }
//        if  ( ( getLeftsDouble() == 1d) && (getKelas() == 0d) ) {
//            return "FP";
//        }
//        if  ( ( getLeftsDouble()== 1d) && (getKelas()== 1d) ) {
//            return "TN";
//        }
        return "null";
    }

    public tomat(String jenisTomat, String diameter,String bentuk, String warna,  String usia, String hiperglikemia) {
        this.jenisTomat = jenisTomat;
        this.bentuk = bentuk;
        this.warna = warna;
        this.diameter = diameter;
        this.usia = usia;
        this.hiperglikemia = hiperglikemia;
    }
    @CsvBindByName
    private String jenisTomat;

    /**
     * Get the value of jenisTomat
     *
     * @return the value of jenisTomat
     */
    public String getJenisTomat() {
        return jenisTomat;
    }

    /**
     * Set the value of jenisTomat
     *
     * @param jenisTomat new value of jenisTomat
     */
    public void setJenisTomat(String jenisTomat) {
        this.jenisTomat = jenisTomat;
    }
    @CsvBindByName
    private String bentuk;

    /**
     * Get the value of bentuk
     *
     * @return the value of bentuk
     */
    public String getBentuk() {
        return bentuk;
    }

    /**
     * Set the value of bentuk
     *
     * @param bentuk new value of bentuk
     */
    public void setBentuk(String bentuk) {
        this.bentuk = bentuk;
    }
    @CsvBindByName
    private String warna;

    /**
     * Get the value of warna
     *
     * @return the value of warna
     */
    public String getWarna() {
        return warna;
    }

    /**
     * Set the value of warna
     *
     * @param warna new value of warna
     */
    public void setWarna(String warna) {
        this.warna = warna;
    }
    @CsvBindByName
    private String diameter;

    /**
     * Get the value of diameter
     *
     * @return the value of diameter
     */
    public String getDiameter() {
        return diameter;
    }

    /**
     * Set the value of diameter
     *
     * @param diameter new value of diameter
     */
    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }
    @CsvBindByName
    private String usia;

    /**
     * Get the value of usia
     *
     * @return the value of usia
     */
    public String getUsia() {
        return usia;
    }

    /**
     * Set the value of usia
     *
     * @param usia new value of usia
     */
    public void setUsia(String usia) {
        this.usia = usia;
    }
    @CsvBindByName
    private String hiperglikemia;

    /**
     * Get the value of hiperglikemia
     *
     * @return the value of hiperglikemia
     */
    public String getHiperglikemia() {
        return hiperglikemia;
    }

    /**
     * Set the value of hiperglikemia
     *
     * @param hiperglikemia new value of hiperglikemia
     */
    public void setHiperglikemia(String hiperglikemia) {
        this.hiperglikemia = hiperglikemia;
    }

    private String klasifikasi;

    /**
     * Get the value of klasifikasi
     *
     * @return the value of klasifikasi
     */
    public String getKlasifikasi() {
        return klasifikasi;
    }

    /**
     * Set the value of klasifikasi
     *
     * @param klasifikasi new value of klasifikasi
     */
    public void setKlasifikasi(String klasifikasi) {
        this.klasifikasi = klasifikasi;
    }

}
